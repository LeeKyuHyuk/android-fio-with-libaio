fio - Flexible I/O tester rev. |version|
========================================


.. include:: ../README.rst


.. include:: ../HOWTO.rst

.. only:: not man

        Examples
        ========

        .. include:: fio_examples.rst



        TODO
        ====


        GFIO TODO
        ---------

        .. include:: ../GFIO-TODO


        Server TODO
        -----------

        .. include:: ../SERVER-TODO


        Steady State TODO
        -----------------

        .. include:: ../STEADYSTATE-TODO



        Moral License
        =============

        .. include:: ../MORAL-LICENSE


        License
        =======

        .. literalinclude:: ../COPYING
